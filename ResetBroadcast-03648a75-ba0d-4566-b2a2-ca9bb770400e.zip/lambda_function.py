import json
import urllib3
import boto3

#websocket endpoint
client = boto3.client('apigatewaymanagementapi', endpoint_url="https://ge3oft6oc0.execute-api.us-east-1.amazonaws.com/production")

def lambda_handler(event, context):

    print(event)

    # Initialize DynamoDB Document Client 
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table('ResetID')  # Replace with your table name
    # Initialize DynamoDB Document Client 
    Table = dynamodb.Table('ResetRecords')  # Replace with your table name


    # Get connectionId data from DynamoDB
    try:
        # Scan DynamoDB table and get all items
        response = table.scan().get('Items', [])
        if not response:
            print("No connection IDs found in the table.")
        
        # Loop through each item and post data to all connection IDs
        for item in response:
            if event["Reset"] == "True":
                try:
                    connectionId = item["connectionId"]
                    
                    #post to connection
                    client.post_to_connection(ConnectionId=connectionId, Data=json.dumps(event).encode('utf-8'))

                    print(f"Posted to connection ID: {connectionId}")

                except Exception as e:
                    print(f"Error posting to connection ID {connectionId}: {e}")
        
    except Exception as e:
        print(f"Error retrieving data from DynamoDB: {e}")

    