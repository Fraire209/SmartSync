import { SESClient, SendEmailCommand } from "@aws-sdk/client-ses";

const sesClient = new SESClient({ region: "us-east-1" });

export const handler = async (event) => {
  console.log("Received event:", JSON.stringify(event, null, 2));
  let camera = event.Camera;
  let pir = event.PIR;
  
  console.log("Camera:", camera);
  console.log("PIR:", pir);
  
  let params = null;

  try {
    if (camera) {
      params = {
        Source: "contactsmartsync@gmail.com", // Verified SES email
        Destination: {
          ToAddresses: ["contactsmartsync@gmail.com"],
        },
        Message: {
          Subject: {
            Data: `Hardware Error Message from Camera`,
          },
          Body: {
            Text: {
              Data: `${camera}`,
            },
          },
        },
      };
    } else if (pir) {
      params = {
        Source: "contactsmartsync@gmail.com", // Verified SES email
        Destination: {
          ToAddresses: ["contactsmartsync@gmail.com"],
        },
        Message: {
          Subject: {
            Data: `Hardware Error Message from PIR`,
          },
          Body: {
            Text: {
              Data: `${pir}`,
            },
          },
        },
      };
    }

    if (!params) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "No valid input data (Camera or PIR) provided" }),
      };
    }

    const command = new SendEmailCommand(params);
    await sesClient.send(command);

    return {
      statusCode: 200,
      body: JSON.stringify({ message: "Message sent successfully!" }),
    };
  } catch (error) {
    console.error("Error sending email:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Failed to send email" }),
    };
  } 
};

