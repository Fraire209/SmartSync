import json
import boto3

def lambda_handler(event, context):

    # Initialize DynamoDB Document Client 
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table('ResetRecords')

    try:
        #scan table
        items = table.scan().get('Items')
        
    except Exception as e:
        print(f"Error: {e}")
        return {
            "statusCode": 500,
            "body": f"Unable to scan the table: {e}"
        }

    return(items)