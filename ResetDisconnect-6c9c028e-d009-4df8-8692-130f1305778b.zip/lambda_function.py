import json
import boto3
import botocore.exceptions

def lambda_handler(event, context):
    print(event)
    print("****")
    print(context)
    
    # Get connection ID
    connection_id = event["requestContext"].get("connectionId") 
    
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')

    # Initialize DynamoDB Document Client 
    table = dynamodb.Table('ResetID')  # Replace with your table name

    
    # Delete data from DynamoDB
    try:
        response = table.delete_item(Key={"connectionId": connection_id})
        print("Data successfully deleted from DynamoDB:", response)
        return {"statusCode" : 200 }
    except Exception as e: 
         print(f"Error deleting to DynamoDB: {e.response['Error']['Message']}")
