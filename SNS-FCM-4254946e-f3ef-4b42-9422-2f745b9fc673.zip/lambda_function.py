import json
import boto3

def lambda_handler(event, context):
    # TODO implement
    token = event['token']
    print(event)
    print('****************************************')
    

    sns = boto3.client('sns', region_name='us-east-1')

    #add FCM tokens to sns
    response = sns.create_platform_endpoint(
        PlatformApplicationArn='arn:aws:sns:us-east-1:084375574875:app/GCM/SmartSync',
        Token=token
    )

    print(response['EndpointArn'])

    endpoint_arn = response['EndpointArn']
    
    #subscribe the tokens to the topic
    response = sns.subscribe(
    TopicArn='arn:aws:sns:us-east-1:084375574875:smartsync-notifications',
    Protocol='application',
    Endpoint=endpoint_arn
    )



    
