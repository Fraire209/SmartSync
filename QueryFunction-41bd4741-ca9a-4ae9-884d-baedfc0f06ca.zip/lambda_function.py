import boto3
import json
from datetime import datetime

def lambda_handler(event, context):
    partitionValue = event["PartitionKey"]
    sortValue = event["SortKey"]

    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table('SmartSync')

    matching_dicts = []

    try:
        # Query by Room (partition key)
        response = table.query(
            KeyConditionExpression=boto3.dynamodb.conditions.Key('Room').eq(partitionValue)
        )

        items = response.get('Items', [])
        while 'LastEvaluatedKey' in response:
            response = table.query(
                KeyConditionExpression=boto3.dynamodb.conditions.Key('Room').eq(partitionValue),
                ExclusiveStartKey=response['LastEvaluatedKey']
            )
            items.extend(response.get('Items', []))

    except Exception as e:
        print(f"Error during query: {e}")
        return {
            "statusCode": 500,
            "body": f"Query failed: {e}"
        }

    print(f"Total items retrieved for Room '{partitionValue}': {len(items)}")


    try:
        if partitionValue and not sortValue:
            matching_dicts = items

        elif partitionValue and sortValue:
            # Check if we should match by hour (e.g., "01:00 PM")
            sortValue = sortValue.strip()
            match_hour = sortValue.endswith(":00 AM") or sortValue.endswith(":00 PM")


            try:
                if match_hour:
                    # Extract hour and AM/PM from "01:00 PM" → ("01", "PM")
                    sort_dt = datetime.strptime(sortValue, "%I:%M %p")
                    sort_hour = sort_dt.strftime("%I")
                    sort_period = sort_dt.strftime("%p")

                    #print(f"Looking for items in the hour of: {sort_hour} {sort_period}")

                    for item in items:
                        ts = item.get("Timestamp")
                        #print(f"Raw timestamp value from item: '{ts}'")

                        if ts:
                            try:
                                item_dt = datetime.strptime(ts.strip(), "%I:%M:%S %p")
                                item_hour = item_dt.strftime("%I")
                                item_period = item_dt.strftime("%p")

                                #print(f"Checking item timestamp: {ts} → hour: {item_hour}, period: {item_period}")

                                if item_hour == sort_hour and item_period == sort_period:
                                    matching_dicts.append(item)

                            except Exception as e:
                                print(f"Could not parse timestamp '{ts}': {e}")

                else:
                    # Match exactly using Time
                    for item in items:
                        if item.get("Time", "").strip() == sortValue:
                            matching_dicts.append(item)

            except ValueError as ve:
                return {
                    "statusCode": 400,
                    "body": f"Invalid time format in SortKey: {ve}"
                }

    except Exception as e:
        print(f"Processing error: {e}")
        return {
            "statusCode": 500,
            "body": f"Processing failed: {e}"
        }

    if not matching_dicts:
        print("No matching dictionaries found.")
        return json.dumps("No Records Found")

    print(f"Total matching dictionaries found: {len(matching_dicts)}")
    print("Matching dictionaries:")
    for match in matching_dicts:
        print(match)

    return matching_dicts
