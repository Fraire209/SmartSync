import json
import boto3

def lambda_handler(event, context):
    print(event)
    print("****")
    print(context)
    
    # Get connection ID
    connection_id = event["requestContext"].get("connectionId") 

    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')

    # Initialize DynamoDB Document Client 
    table = dynamodb.Table('ResetID')  # Replace with your table name

    # Define the item to put into the table
    item = {
        "connectionId": connection_id
    }

    # Write data to DynamoDB
    try:
        response = table.put_item(Item=item)
        print("Data successfully written to DynamoDB:", response)
        return {"statusCode" : 200}
         

    except Exception as e: 
         print(f"Error writing to DynamoDB: {e.response['Error']['Message']}")

