import json
import boto3
import re
import datetime

def lambda_handler(event, context):
    
    #iterate over each record
    try:
        for record in event['Records']:
            if record['eventName'] == 'INSERT':
                handle_insert(record)
    
    except Exception as e:
        print(e)
        return "Failed"



def handle_insert(record):

    #get new image
    newImage = record['dynamodb']['NewImage']

    #parse values
    newRoom = newImage['Room']['S']
    newTimestamp = newImage['Timestamp']['S']
    newDate = newImage['Date']['S']
    newLocation = newImage['Location']['S']
    newTemperature = newImage['Temperature']['S']
    newTime = newImage['Time']['S']

    #print
    print(newTimestamp)
    print(newDate)
    print(newLocation)
    print(newTemperature)

    #initialize dynamoDB resource
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')

    # Initialize DynamoDB Document Client 
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('UpdatedRecords') 

    #payload
    payload = {
        "Location" : newLocation,
        "Timestamp" : newTimestamp,
        "Date" : newDate,
        "Temperature" : newTemperature
        }

    # Write data to UpdatedRecords
    try:
        response = table.put_item(Item=payload)
        print("Data successfully written to DynamoDB:")
    
    except Exception as e: 
         print(f"Error writing to DynamoDB: {e.response['Error']['Message']}")

    #Write data to Incidents if high temperature

    #payload
    Payload = {
        "Room" : newRoom,
        "Location" : newLocation,
        "Timestamp" : newTimestamp,
        "Date" : newDate,
        "Temperature" : newTemperature,
        "Time" : newTime
        }

    #payload in case of reset table insertion
    PayloadReset = {
        "Room" : newLocation,
        "Reset" : "False"
    }

    # Initialize DynamoDB for Scan  
    table = dynamodb.Table('Incidents')  # Replace with your table name
    TableReset = dynamodb.Table('ResetRecords')  # Replace with your table name
    
    # Initialize AWS Lambda client
    lambda_client = boto3.client('lambda', region_name='us-east-1')

    try:
        # Convert and check the temperature
        numeric_temperature = extract_numeric_temperature(Payload["Temperature"])
        
        if numeric_temperature >= 100.4:   # Scaled down five degrees due to heat camera 
            # Add the payload to the DynamoDB table
            table.put_item(Item=Payload)
            TableReset.put_item(Item=PayloadReset)
            try:
                # Asynchronously invoke the target Lambda function
                response = lambda_client.invoke(
                FunctionName='incidentbroadcast',
                InvocationType='Event',  # Asynchronous invocation
                Payload=json.dumps(Payload)
                )
                    

                
    
            except Exception as e:
                print(f"Error invoking target Lambda: {str(e)}")
                return {
                    "statusCode": 500,
                }

    except ValueError as e:
        print(f"Error: {e}")


    

    # Initialize DynamoDB for Scan  
    table = dynamodb.Table('UpdatedRecords')  # Replace with your table name

    try:
        #scan table
        items = table.scan().get('Items')
        
    except Exception as e:
        print(f"Error: {e}")
        return {
            "statusCode": 500,
            "body": f"Unable to scan the table: {e}"
        }
            
    

    # Initialize AWS Lambda client
    lambda_client = boto3.client('lambda', region_name='us-east-1')
    try:
        # Asynchronously invoke the target Lambda function
        response = lambda_client.invoke(
        FunctionName='broadcastupdate',
        InvocationType='Event',  # Asynchronous invocation
        Payload=json.dumps(items)
        )
            

        print("Data successfully sent as event")
        return {
            "statusCode": 200
        }

                
    except Exception as e:
        print(f"Error invoking target Lambda: {str(e)}")
        return {
            "statusCode": 500,
        }

# Extract numeric value from temperature string
def extract_numeric_temperature(temp_str):
    # Use regex to extract the first valid number in the string
    match = re.search(r"[-+]?\d*\.?\d+", temp_str)
    if match:
        return float(match.group())
    else:
        raise ValueError(f"Invalid temperature format: {temp_str}")

