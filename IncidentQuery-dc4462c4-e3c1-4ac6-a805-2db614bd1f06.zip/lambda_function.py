import json
import boto3

def lambda_handler(event, context):

    #extract date from request
    Date = event["DateValue"]
    # Replace dashes with slashes
    formatted_date = Date.replace("-", "/")
    #error message
    error= "No Record Found"

    # Initialize DynamoDB Document Client 
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table('Incidents')

    try:
        #scan table
        items = table.scan().get('Items')
        
    except Exception as e:
        print(f"Error: {e}")
        return {
            "statusCode": 500,
            "body": f"Unable to scan the table: {e}"
        }


    try:
        # Iterate through the dictionaries and print matching ones
        matching_dicts = []

        for item in items:
            if(item.get("Date") == formatted_date):
                matching_dicts.append(item)

    except Exception as e:
        print(f"Error: {e}")
        return {
            "statusCode": 500,
            "body": f"Unable to process the request: {e}"
        }
        
    # Log or return the matching dictionaries
    if matching_dicts:
        print("Matching dictionaries:")
        for match in matching_dicts:
            print(match)
    
    else:
        print("No matching dictionaries found.")
        matching_dicts=json.dumps(error)
     
    return(matching_dicts)


    

