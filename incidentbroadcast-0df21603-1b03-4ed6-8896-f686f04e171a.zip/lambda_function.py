import json
import urllib3
import boto3

#websocket endpoint
client = boto3.client('apigatewaymanagementapi', endpoint_url="https://aazjpa4x4d.execute-api.us-east-1.amazonaws.com/production")

def lambda_handler(event, context):

    print(event)

    # Initialize DynamoDB Document Client 
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table('IncidentConnectionId')  # Replace with your table name

    # Get connectionId data from DynamoDB
    try:
        # Scan DynamoDB table and get all items
        response = table.scan().get('Items', [])
        if not response:
            print("No connection IDs found in the table.")
        
        # Loop through each item and post data to all connection IDs
        for item in response:
            try:
                connectionId = item["connectionId"]
                client.post_to_connection(ConnectionId=connectionId, Data=json.dumps(event).encode('utf-8'))

                print(f"Posted to connection ID: {connectionId}")
            except Exception as e:
                print(f"Error posting to connection ID {connectionId}: {e}")
        
    except Exception as e:
        print(f"Error retrieving data from DynamoDB: {e}")

    #initialize sns to send topic to FCM endpoints
    sns = boto3.client('sns', region_name='us-east-1')

    # Format the message
    message = {
        "default": "This is the default message.",
        "GCM": json.dumps({
            "notification": {
                "title": "WARNING",
                "body": f"There has been a high temperature recorded in room {event['Location']} at {event['Timestamp']}. Please stay clear until further notice."
            }
        })
    }


    publish_response = sns.publish(
        TopicArn='arn:aws:sns:us-east-1:084375574875:smartsync-notifications',
        Message=json.dumps(message),
        MessageStructure='json'
    )
    print(f"Message published. Message ID: {publish_response['MessageId']}")

   