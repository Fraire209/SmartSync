import json
import urllib3
import boto3

#websocket endpoint
client = boto3.client('apigatewaymanagementapi', endpoint_url="https://x290qiinj3.execute-api.us-east-1.amazonaws.com/production")

def lambda_handler(event, context):

    #extract dictionaries from event dynamically
    for i in range(len(event)):
        locals()[f"dict{i+1}"] = event[i]

    #print every dictionary
    for i in range(len(event)):
        print(f"dict{i+1}: {locals()[f'dict{i+1}']}")

    # Initialize DynamoDB Document Client 
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table('IDRecords')  # Replace with your table name

    # Get connectionId data from DynamoDB
    try:
        # Scan DynamoDB table and get all items
        response = table.scan().get('Items', [])
        if not response:
            print("No connection IDs found in the table.")
        
        # Loop through each item and post data to all connection IDs
        for item in response:
            try:
                connectionId = item["connectionId"]
                
                #loop for number of dictionaries in event to post to connection
                for i in range(len(event)):
                    answer = client.post_to_connection(ConnectionId=connectionId, Data=json.dumps(locals()[f'dict{i+1}']).encode('utf-8'))

                print(f"Posted to connection ID: {connectionId}")
            except Exception as e:
                print(f"Error posting to connection ID {connectionId}: {e}")
        
    except Exception as e:
        print(f"Error retrieving data from DynamoDB: {e}")


   

