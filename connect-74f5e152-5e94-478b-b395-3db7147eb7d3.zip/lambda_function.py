import json
import boto3
from boto3.dynamodb.types import TypeDeserializer
import urllib3



def lambda_handler(event, context):
    print(event)
    print("****")
    print(context)
    
    # Get connection ID
    connection_id = event["requestContext"].get("connectionId") 

    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')

    # Initialize DynamoDB Document Client 
    table = dynamodb.Table('IDRecords')  # Replace with your table name

    # Define the item to put into the table
    item = {
        "connectionId": connection_id
    }

    # Write data to DynamoDB
    try:
        response = table.put_item(Item=item)
        print("Data successfully written to DynamoDB:", response)
         

    except Exception as e: 
         print(f"Error writing to DynamoDB: {e.response['Error']['Message']}")

    ##################################################################################################################  
    # Initialize DynamoDB Document Client 
    table = dynamodb.Table('UpdatedRecords')  # Replace with your table name

    
    try:
        #scan table
        items = table.scan().get('Items')
        
    except Exception as e:
        print(f"Error: {e}")
        return {
            "statusCode": 500,
            "body": f"Unable to scan the table: {e}"
        }

   
    # Initialize AWS Lambda client
    lambda_client = boto3.client('lambda', region_name='us-east-1')
    try:
        # Asynchronously invoke the target Lambda function
        response = lambda_client.invoke(
        FunctionName='broadcastupdate',
        InvocationType='Event',  # Asynchronous invocation
        Payload=json.dumps(items)
        )
            

        return {
            "statusCode": 200,
        }

                
    except Exception as e:
        print(f"Error invoking target Lambda: {str(e)}")
        return {
            "statusCode": 500,
        }


    
