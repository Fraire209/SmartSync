import { SESClient, SendEmailCommand } from "@aws-sdk/client-ses";

const sesClient = new SESClient({ region: "us-east-1" });

export const handler = async (event) => {
  console.log("Received event:", JSON.stringify(event, null, 2));
  try {
    const body = JSON.parse(event.body);
    const { name, number, email, message } = body;

    if (!name || !email || !number || !message) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "All fields are required" }),
      };
    }

    const params = {
      Source: "contactsmartsync@gmail.com", // Verified SES email
      Destination: {
        ToAddresses: ["contactsmartsync@gmail.com"],
      },
      Message: {
        Subject: {
          Data: `SmartSync Contact Request from ${name}`,
        },
        Body: {
          Text: {
            Data: `Name: ${name}\nNumber: ${number}\nEmail: ${email}\nMessage: ${message}`,
          },
        },
      },
    };

    const command = new SendEmailCommand(params);
    await sesClient.send(command);

    return {
      statusCode: 200,
      body: JSON.stringify({ message: "Message sent successfully!" }),
    };
  } catch (error) {
    console.error("Error sending email:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Failed to send email" }),
    };
  }
};
