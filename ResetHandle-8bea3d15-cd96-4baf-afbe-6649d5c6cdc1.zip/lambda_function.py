import json
import boto3

def lambda_handler(event, context):
    
    #iterate over each record
    try:
        for record in event['Records']:
            if record['eventName'] == 'MODIFY':
                handle_insert(record)
    
    except Exception as e:
        print(e)
        return "Failed"

def handle_insert(record):
    print("Handling MODIFY Event")

    #get newImage content
    newImage = record['dynamodb']['NewImage']

    #parse newImage
    Room = newImage['Room']['S']
    Reset = newImage['Reset']['S']

    #format payload 
    Payload = {
        "Room": Room,
        "Reset": Reset
    }
    
    #send payload to lambda
    lambda_client = boto3.client('lambda', region_name='us-east-1')

    try:
        response = lambda_client.invoke(
            FunctionName='ResetBroadcast',
            InvocationType='Event',
            Payload=json.dumps(Payload)
        )
        print("Data successfully sent as event")
        return {
            "statusCode": 200
        }

                
    except Exception as e:
        print(f"Error invoking target Lambda: {str(e)}")
        return {
            "statusCode": 500,
        }

